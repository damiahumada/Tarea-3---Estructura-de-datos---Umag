#ifndef FILE_READER_H
#define FILE_READER_H

/*Esta funcion es la encargada de leer la secuencia de adn, 
hace las validaciones necesarias para que no haya errores. 
*/
char* leer_secuencia(char* nombre_archivo);

#endif
