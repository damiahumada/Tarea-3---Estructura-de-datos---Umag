#include "file_reader.h"
#include <stdio.h>
#include <stdlib.h>

char* leer_secuencia(char* nombre_archivo)
{
    int caracter_leido;
    //para 
    char* secuencia = NULL; //seceuncia al string gigante que contruiremos
    int tamano_temp = 0; //guarda cuanta memoria pedimos.
    int longitud_secuencia = 0; //guarda la cantidad de caracteres que se ha guardado
    int i=0;

    FILE *p = fopen(nombre_archivo,"r");
    if(!p)
    {
        printf ("El archivo no se pudo abrir\n");
        return NULL;
    }
    //ahora vemos si el tamaño del archivo de la secuencia es valido.
    while ((caracter_leido = fgetc(p)) != EOF)
    {
        if (caracter_leido == '\n') 
        {
            
            break; // Sale del bucle 'while'
        } 
        longitud_secuencia++;
    }
    secuencia=malloc(longitud_secuencia+1);
    if (secuencia == NULL) 
    {
        printf("Error: No se pudo asignar memoria.\n");
        fclose(p);
        return NULL;
    }

    //ahora si podemos guardar en un string
    FILE *p_ = fopen(nombre_archivo,"r");

    while ((caracter_leido = fgetc(p_)) != EOF && caracter_leido != '\n') 
    {    
        secuencia[i] = (char)caracter_leido;
        i++;
        
        // (Pequeña seguridad por si acaso, aunque 'i' debe ser igual a 'longitud')
        if (i >= longitud_secuencia) 
        {
            break;
        }
    }
    // Ponemos el terminador nulo al final
    secuencia[i] = '\0';
    // Cerramos el archivo
    fclose(p);
    fclose(p_);
    // Devolvemos el puntero a la memoria recién llenada
    return secuencia;
}